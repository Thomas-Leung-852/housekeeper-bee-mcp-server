---
name: hb-storage-treemap
description: >
  Builds an interactive 3-level drill-down storage tree map using live data
  from the Housekeeper Bee MCP server and Plotly.js. Visualises all storage
  locations and boxes with colour-coded occupancy levels (Low / Medium / High).
  Use when the user asks to visualise, map, explore, or browse their storage —
  e.g. "show me a storage tree map", "where is everything stored?",
  "storage map", "show my boxes by location", "build a storage explorer".
version: "1.1.0"
author: ""
license: MIT
requires:
  mcp:
    - name: "housekeeper bee mcp server"
      tools:
        - findStorageLocationByName
        - findStorageBoxes
artifact_type: html
tags:
  - housekeeper-bee
  - storage
  - treemap
  - plotly
  - visualisation
---

# Skill: Storage Tree Map (`hb-storage-treemap`)

## Description

Use this skill whenever the user asks to **visualise**, **map**, **explore**, or **browse**
their Housekeeper Bee storage data as an interactive tree map.

Trigger phrases include:
- "show me a storage tree map"
- "storage map / storage visualisation"
- "where is everything stored?"
- "show my boxes by location"
- "build a storage explorer"

This skill fetches **live data** from the Housekeeper Bee MCP server, then builds a
fully interactive 3-level drill-down tree map rendered as a **single-file HTML artifact**
using **Plotly.js** (CDN) inside a React/JSX wrapper.

---

## Prerequisites

- The **Housekeeper Bee MCP server** must be connected to the current chat session.
- No authentication tokens are needed for read-only operations.

---

## Step 1 — Fetch Live Data from MCP

Call **both** tools before writing any code:

```
Tool: housekeeper bee mcp server:findStorageLocationByName
  locationName: "*"

Tool: housekeeper bee mcp server:findStorageBoxes
  keywords: "*"
```

**Fields to extract:**

| Source    | Required fields |
|-----------|----------------|
| Locations | `locationCode`, `locationName`, `numOfStorage` |
| Boxes     | `storageCode`, `storageName`, `storageDesc`, `storageStatus`, `storageRemark`, `locationCode`, `tags` |

> Do **NOT** embed real user data into the artifact source code.  
> Assign the fetched arrays to `const LOCATIONS = [...]` and `const BOXES = [...]`
> at the top of the script — these are populated fresh each session and never persisted.

---

## Step 2 — Color Threshold Rules

### Percentage formula — Level 1 (Locations treemap)
```
val = (numOfStorage for this location / total numOfStorage across ALL locations) × 100
```

### Percentage formula — Level 2 (Boxes inside a location treemap)
```
val = (estimated item count of this box / total estimated items across ALL boxes in this location) × 100
```

### Color mapping (apply to BOTH levels)
| val range | Color  | Label  | Hex       |
|-----------|--------|--------|-----------|
| 0 – 10%   | Green  | Low    | `#2db84b` |
| 11 – 75%  | Yellow | Medium | `#f0c30f` |
| > 75%     | Red    | High   | `#e8362a` |

```js
function pctToLevel(v) {
  if (v <= 10) return { label: 'Low',    color: '#2db84b' };
  if (v <= 75) return { label: 'Medium', color: '#f0c30f' };
  return             { label: 'High',   color: '#e8362a' };
}
```

---

## Step 3 — Item Count Estimator

Used to size boxes in Level 2 treemap:

```js
function countItems(desc) {
  if (!desc) return 1;
  const mults = desc.match(/x\s*(\d+)/gi) || [];
  let sum = 0, hasX = false;
  mults.forEach(m => { sum += parseInt(m.replace(/x\s*/i, '')) || 0; hasX = true; });
  const parts = (desc.match(/,/g) || []).length + 1;
  return hasX ? Math.max(sum, parts) : parts;
}
```

Use `Math.max(count, 0.5)` as a floor so even single-item boxes render as a visible tile.

---

## Step 4 — Plotly Treemap (Core Rendering)

Use **Plotly.js** from CDN — no custom squarify algorithm needed:

```html
<script src="https://cdnjs.cloudflare.com/ajax/libs/plotly.js/2.27.0/plotly.min.js"></script>
```

### Trace structure
```js
function buildTrace(labels, parents, values, colors, customdata, text) {
  return [{
    type: 'treemap',
    labels,  parents,  values,
    marker: { colors, line: { width: 1.5, color: '#18181f' } },
    customdata,
    text,                        // shown inside each tile: "Level\nXX.X%"
    textposition: 'top left',
    textfont: { size: 13, color: '#fff' },
    hovertemplate: '%{customdata}<extra></extra>',
    tiling: { packing: 'squarify', pad: 0 },
    pathbar: { visible: false },
  }];
}
```

### Layout & config
```js
const LAYOUT = {
  margin: { l: 0, r: 0, t: 0, b: 0 },
  paper_bgcolor: 'rgba(0,0,0,0)',
  plot_bgcolor:  'rgba(0,0,0,0)',
  font: { family: "'Helvetica Neue', Arial, sans-serif" },
};
const CONFIG = { displayModeBar: false, responsive: true };
```

### Root node
Always include a hidden root node as the first element:
```js
const labels  = ['root', ...items.map(i => i.name)];
const parents = ['',    ...items.map(() => 'root')];
const values  = [0,     ...items.map(i => i.value)];
const colors  = ['rgba(0,0,0,0)', ...items.map(i => pctToLevel(i.pct).color)];
```

### Tile text (shown inside each tile)
```js
const text = ['', ...items.map(i => `${pctToLevel(i.pct).label}<br>${i.pct.toFixed(1)}%`)];
```

### Click handler for drill-down
```js
Plotly.newPlot('plotly-chart', trace, LAYOUT, CONFIG);
document.getElementById('plotly-chart').on('plotly_click', d => {
  const pt = d.points[0];
  if (!pt || pt.label === 'root') return;
  // navigate to next level
});
```

---

## Step 5 — Three Navigation Levels

### Level 1 — "All Locations" treemap
- One tile per location (exclude locations where `numOfStorage === 0`).
- Tile **size** = `numOfStorage`.
- Color = percentage of total boxes (see Step 2).
- Click → drill into Level 2 for that location.

### Level 2 — "Location" treemap
- One tile per box inside the selected location.
- Tile **size** = `countItems(storageDesc)`.
- Color = percentage of total items within this location only (see Step 2).
- Click → show Level 3 box detail panel.

### Level 3 — "Box" detail list
- **Hide** the Plotly chart div, **show** the detail panel div.
- Parse `storageDesc` by splitting on `,` — detect `x N` quantity suffix.
- Display: box name, location name, level+percentage badge, status badge, tags, contents list, remark.

---

## Step 6 — UI Structure

### Navigation breadcrumb
```
📦 All Locations  ›  [Location Name]  ›  [Box Name]
```
- Always visible at the top.
- Earlier crumbs are clickable links that navigate back.
- Current level is highlighted.

### Legend row (always visible)
```
🟢 Low (0–10%)   🟡 Medium (11–75%)   🔴 High (>75%)
```

### Status badge colors for box detail
| Status keyword | Badge color |
|----------------|-------------|
| `full` / `Full` | Red `#e8362a` |
| `75%` | Orange `#ff9500` |
| `50%` | Yellow `#f0c30f` |
| `25%` / `Check-Out` | Green `#2db84b` |

### Dark theme
- Background: `#18181f`
- Chart area: `#111116`
- Text primary: `#eeeeff`, secondary: `#4d5f8a`, muted: `#3a3a52`
- Tile gap: `1.5px` via `marker.line`

---

## Step 7 — Artifact Format

Deliver as a **single self-contained HTML file** (not JSX):
- All CSS inline in `<style>` tags.
- Plotly loaded from CDN.
- All JS inline in `<script>` tags.
- `LOCATIONS` and `BOXES` arrays embedded at the top of the script (populated from MCP, not hardcoded sample data).
- No external files, no build step.

The demo file `storage-treemap-demo.html` (in this skill folder) contains **English sample data only** and is safe to share publicly. When running live, replace `LOCATIONS` and `BOXES` with data fetched fresh from MCP.

---

## Step 8 — Quality Checklist

- [ ] Both MCP tools called before building the artifact
- [ ] `LOCATIONS` and `BOXES` populated from live MCP results
- [ ] No personal/real user data hardcoded in file
- [ ] Color thresholds: Low ≤10%, Medium ≤75%, High >75%
- [ ] All three levels navigate correctly
- [ ] Breadcrumb updates at each level and navigates back correctly
- [ ] Locations with `numOfStorage === 0` excluded from Level 1
- [ ] Box detail correctly parses `x N` quantities from `storageDesc`
- [ ] Plotly CDN script loaded before any `Plotly.*` calls
- [ ] `displayModeBar: false` set (hides the Plotly toolbar)
- [ ] `responsive: true` set (auto-resizes with panel)
- [ ] Root node colour is `rgba(0,0,0,0)` (transparent / invisible)

---

## Notes

- Data is always fetched **live** — never cached between sessions.
- `countItems()` is a heuristic estimate. For exact counts, users should add structured quantity fields in Housekeeper Bee.
- The Plotly `pathbar` is disabled (`pathbar: { visible: false }`) because the custom breadcrumb handles navigation instead.
- Tile labels that are too long for small tiles will be clipped by Plotly automatically.
